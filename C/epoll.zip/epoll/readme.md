how to use:
g++ server.cpp utility.h -o server
g++ client.cpp utility.h -o client
./server
./client